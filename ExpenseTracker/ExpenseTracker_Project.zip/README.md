
# Expense Tracker Application

This is a simple Java-based desktop Expense Tracker that helps users to manage their income and expenses effectively. The application allows users to:

- Add income and expenses
- Categorize transactions
- View monthly summaries
- Load and save data from/to a file

## Features

1. **Add Transaction**
   - Add an income or an expense
   - Specify category, amount, and description
   

2. **Monthly Summary**
   - Displays total income and total expenses for the current month
   
3. **Save File**
   - Save your transaction history to a text file

4. **Load File**
   - Load previously saved transactions into the application

## Screenshots

### 1. Transaction Added
![Transaction Added](Transaction%20added.png)

### 2. Monthly Summary
![Monthly Summary](Monthly%20Summary.png)

### 3. Save File
![Save File](Save%20File.png)

### 4. Load File
![Load File](Load%20File.png)

## How to Run

1. Compile the Java files using your preferred IDE or terminal.
2. Run the main class to launch the application.
3. Start managing your expenses!

---

Created by: [Haseeb Raiyan]
